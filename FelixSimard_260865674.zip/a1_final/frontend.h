/*

COMP 310 / ECSE 427 - Operating Systems
Assignment 1
Felix Simard (260865674)

*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "helper.h" // our custom helper functions for parsing inputs and other

#define BUFSIZE 1024

int main(int argc, char *argv[]);
